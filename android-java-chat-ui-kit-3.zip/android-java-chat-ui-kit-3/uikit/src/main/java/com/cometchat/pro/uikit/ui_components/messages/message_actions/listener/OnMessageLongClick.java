package com.cometchat.pro.uikit.ui_components.messages.message_actions.listener;

import com.cometchat.pro.models.BaseMessage;

import java.util.List;

public interface OnMessageLongClick
{
    void setLongMessageClick(List<BaseMessage> baseMessage);
}
